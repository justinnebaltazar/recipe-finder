# 🍲 Recipe Finder — CMPT362 (Group 19)

**Team Members:**
- Justinne Baltazar
- Kevin Le
- Mark Vu
- Brian Huang
- Yan Ting Leung

---

## Overview
Recipe Finder is an Android application that generates recipe suggestions based on user-provided ingredients. Users can either:

- **Enter ingredients manually**, or  
- **Upload an image** for automatic ingredient detection using AI.

The app then returns recipes tailored to the detected or entered ingredients.

---

## Technologies Used

### Backend & AI
- **Google Gemini 2.5 Flash Lite** — Ingredient detection & recipe generation  
- **FastAPI** — Backend server for processing recipe requests  
- **Google Cloud Run** — Hosts the backend server in the cloud  

### Android Development
- **Retrofit** — Networking library for communicating with the Cloud Run backend  
- **Firebase Authentication** — Handles secure user login & account creation  
- **Firebase Firestore** — Stores user data, saved recipes, and profile settings  

