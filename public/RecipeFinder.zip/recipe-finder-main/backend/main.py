import json
import os
import tempfile
from typing import List, Any

import google.generativeai as genai
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field, ValidationError


# ===========================
# ENV + GEMINI SETUP
# ===========================
load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    raise RuntimeError("GEMINI_API_KEY is not set")

genai.configure(api_key=api_key)

MODEL = genai.GenerativeModel("gemini-2.5-flash-lite")


# ===========================
# SCHEMAS
# ===========================
class RecipeRequest(BaseModel):
    ingredients: str


class Ingredient(BaseModel):
    name: str
    amount: str


class RecipeResponse(BaseModel):
    title: str
    servings: str
    time: str
    ingredientsPreview: str
    ingredients: List[Ingredient]
    instructions: List[str]


# ===========================
# PROMPT
# ===========================
PROMPT = """
You are an expert chef and recipe generator.

The user has these ingredients (as free-form text):
\"\"\"{ingredients_text}\"\"\"

Generate AS MANY AS POSSIBLE but still relevant high-quality recipes that use primarily these ingredients.
Relevancy > Quantity. Sort by relevance.

Respond with ONLY a JSON array:
[
  {{
    "title": "...",
    "servings": "...",
    "time": "...",
    "ingredientsPreview": "...",
    "ingredients": [
      {{"name": "...", "amount": "..."}}
    ],
    "instructions": ["...", "..."]
  }}
]

Important:
- Output MUST be valid JSON.
- MUST be a JSON ARRAY only.
- No wrapper like {{"recipes": [...]}}
- No markdown, no explanations.
"""


IMAGE_PROMPT = """
You are an expert chef and recipe generator.

The user has provided a PHOTO of ingredients.

1) Carefully look at the image and infer which ingredients are likely present.
   - Name common ingredients you clearly see.
   - You may assume basic pantry items (oil, salt, pepper, common spices) when reasonable.

2) Using primarily those inferred ingredients, generate AS MANY AS POSSIBLE but still
   relevant high-quality recipes. Relevancy > Quantity. Sort by relevance.

3) Respond with ONLY a JSON array in this exact schema:
[
  {
    "title": "...",
    "servings": "...",
    "time": "...",
    "ingredientsPreview": "...",
    "ingredients": [
      {"name": "...", "amount": "..."}
    ],
    "instructions": ["...", "..."]
  }
]

Important:
- Output MUST be valid JSON.
- MUST be a JSON ARRAY only.
- No wrapper like {"recipes": [...]}
- No markdown, no explanations, no commentary.
"""


# ===========================
# JSON EXTRACTOR (because gemini sometimes outputs extra text)
# ===========================
def extract_json_array(text: str) -> Any:
    """
    Gemini sometimes outputs extra text before/after JSON.
    This extracts the first valid JSON array.
    """

    text = text.strip()

    # If it's already a valid JSON array:
    if text.startswith("[") and text.endswith("]"):
        return json.loads(text)

    # Extract between first '[' and last ']'
    if "[" in text and "]" in text:
        start = text.find("[")
        end = text.rfind("]") + 1
        cleaned = text[start:end]
        return json.loads(cleaned)

    raise ValueError("No JSON array found in Gemini response")


def _parse_recipes_from_text(text: str) -> List[RecipeResponse]:
    if not text:
        raise HTTPException(502, "Empty response from Gemini")

    try:
        json_data = extract_json_array(text)
    except Exception as e:
        raise HTTPException(
            502,
            f"Failed to extract JSON array: {e}. Raw: {text[:200]}..."
        )

    if not isinstance(json_data, list):
        raise HTTPException(502, "Gemini did not return a JSON array")

    # Validate each recipe
    recipes = []
    for item in json_data:
        try:
            recipes.append(RecipeResponse.model_validate(item))
        except ValidationError as e:
            raise HTTPException(
                502,
                f"JSON schema mismatch: {e}"
            )

    return recipes


def _generate_recipe_sync(ingredients_text: str) -> List[RecipeResponse]:
    prompt = PROMPT.format(ingredients_text=ingredients_text)

    try:
        response = MODEL.generate_content(prompt)
    except Exception as e:
        raise HTTPException(502, f"Gemini API error: {e}")

    text = getattr(response, "text", None)
    return _parse_recipes_from_text(text)


def _generate_recipe_from_image_sync(image_path: str) -> List[RecipeResponse]:
    """
    Uploads the image to Gemini and generates recipes directly from the photo.
    """
    try:
        uploaded_file = genai.upload_file(path=image_path)
    except Exception as e:
        raise HTTPException(502, f"Gemini file upload error: {e}")

    try:
        # Send both the image and the instructions as a multi-part prompt
        response = MODEL.generate_content([uploaded_file, IMAGE_PROMPT])
    except Exception as e:
        raise HTTPException(502, f"Gemini API error: {e}")

    text = getattr(response, "text", None)
    return _parse_recipes_from_text(text)

app = FastAPI()


@app.get("/")
def root():
    return {"message": "Recipe Finder backend running"}


@app.post("/recipes", response_model=List[RecipeResponse])
async def generate_recipe(req: RecipeRequest):
    return await run_in_threadpool(_generate_recipe_sync, req.ingredients)


@app.post("/recipes/image", response_model=List[RecipeResponse])
async def generate_recipe_from_image(file: UploadFile = File(...)):
    """
    Accepts an image upload, sends it to Gemini, and returns generated recipes.
    """
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "Uploaded file must be an image")

    # Persist to a temporary file so we can use genai.upload_file
    suffix = os.path.splitext(file.filename or "")[1] or ".jpg"
    try:
        contents = await file.read()
    except Exception:
        raise HTTPException(400, "Failed to read uploaded file")

    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents)
            tmp_path = tmp.name
    except Exception:
        raise HTTPException(500, "Failed to save temporary image file")

    try:
        return await run_in_threadpool(_generate_recipe_from_image_sync, tmp_path)
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            # Best-effort cleanup; ignore failures
            pass
