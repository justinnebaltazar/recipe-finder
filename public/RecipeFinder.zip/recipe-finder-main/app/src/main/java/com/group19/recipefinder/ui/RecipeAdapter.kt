package com.group19.recipefinder.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe

class RecipeAdapter(
    private val items: List<Recipe>,
    private val onRecipeClick: (Recipe) -> Unit
) : RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder>() {

    class RecipeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.recipe_image)
        val title: TextView = itemView.findViewById(R.id.recipe_title)
        val servings: TextView = itemView.findViewById(R.id.recipe_servings)
        val time: TextView = itemView.findViewById(R.id.recipe_time)
        val ingredients: TextView = itemView.findViewById(R.id.recipe_ingredients)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recipe_card, parent, false)
        return RecipeViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecipeViewHolder, position: Int) {
        val recipe = items[position]

        with (holder) {
            image.setImageResource(recipe.imageResId)
            title.text = recipe.title
            servings.text = "${recipe.servings} servings"
            time.text = recipe.time
            ingredients.text = recipe.ingredientsPreview

            itemView.setOnClickListener {
                onRecipeClick(recipe)
            }
        }
    }

    override fun getItemCount() = items.size
}
