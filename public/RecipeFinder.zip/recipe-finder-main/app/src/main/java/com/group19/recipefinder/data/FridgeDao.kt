package com.group19.recipefinder.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FridgeDao {

    @Query("SELECT * FROM fridge_items")
    suspend fun getAll(): List<FridgeItem>

    @Insert
    suspend fun insert(item: FridgeItem): Long

    @Delete
    suspend fun delete(item: FridgeItem)

    @Query("DELETE FROM fridge_items")
    suspend fun clearAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<FridgeItem>)

    @Query("SELECT * FROM fridge_items WHERE name LIKE :prefix || '%'")
    suspend fun searchByPrefix(prefix: String): List<FridgeItem>
}