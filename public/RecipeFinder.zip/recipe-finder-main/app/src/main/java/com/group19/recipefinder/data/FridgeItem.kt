package com.group19.recipefinder.data

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey

@Keep
@Entity(tableName = "fridge_items")
data class FridgeItem(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val name: String = "",
    val addedDate: String = "",
    val itemType: String = "",
    val daysUntilExpiry: Int = 0
) {
    val expiryLabel: String
        get() = if (daysUntilExpiry == 1) "1 day left!" else "$daysUntilExpiry days left!"
}