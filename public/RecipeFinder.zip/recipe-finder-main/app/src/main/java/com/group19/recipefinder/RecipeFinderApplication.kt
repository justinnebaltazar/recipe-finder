package com.group19.recipefinder

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class RecipeFinderApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize Firestore
        val db = FirebaseFirestore.getInstance()
        println("Firestore initialized in Application class!")
    }
}

//Database Schema for firestore?
//users/
//   userID/
//      name:
//      email:
//      fridge/
//          item1
//          item2
//      favorites/
//          recipe1
//          recipe2
//
//public_recipes/
//   publicRecipe1/
//   publicRecipe2/
