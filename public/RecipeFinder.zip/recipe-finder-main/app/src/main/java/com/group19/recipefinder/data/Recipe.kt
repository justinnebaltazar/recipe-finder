package com.group19.recipefinder.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Recipe (
    val id: String = "",
    val author: String = "",
    val title: String = "",
    val servings: String = "",
    val time: String = "",
    val ingredientsPreview: String = "",
    val imageResId: Int, // using drawable food placeholder
    val ingredients: List<Pair<String, String>> = emptyList(),
    val instructions: List<String> = emptyList()
) : Parcelable