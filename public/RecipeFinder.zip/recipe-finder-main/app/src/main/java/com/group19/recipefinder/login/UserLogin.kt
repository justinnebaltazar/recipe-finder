package com.group19.recipefinder.login

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import com.group19.recipefinder.R
import android.widget.EditText
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.TextView

import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

import com.group19.recipefinder.MainActivity



class UserLogin : Fragment() {

    private val PREFERENCE_NAME = "User preference"

    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var rememberMe: CheckBox


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_user_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sharedPreferences = requireActivity().getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        rememberMe = view.findViewById(R.id.remember_me)

        val loginButton = view.findViewById<Button>(R.id.login_button)
        loginButton.setOnClickListener {
            if (checkInput()) {

                checkLogin { success ->
                        if (success) {

                            //Save preferences
                            if (rememberMe.isChecked) {
                                editor.putString("username", username.text.toString())
                                editor.putString("password", password.text.toString())
                                editor.putBoolean("rememberMe", true)
                            } else {
                                editor.remove("username")
                                editor.remove("password")
                                editor.remove("rememberMe")
                            }
                            editor.apply()

                            val result = Bundle()
                            //Sends a key and some data to MainActivity
                            parentFragmentManager.setFragmentResult("login_success", result)
                        }
                }
            }
        }

        val signUpButton = view.findViewById<TextView>(R.id.sign_up_button)
        signUpButton.setOnClickListener {
            val fragment = SignUp()
            //Add fragment to stack, so user will go back to login page after
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()

        }


        expandClickBox(view)

        //Load saved preferences
        val usernameValue = sharedPreferences.getString("username", "")
        val passwordValue = sharedPreferences.getString("password", "")
        val rememberMeValue = sharedPreferences.getBoolean("rememberMe", false)

        if (rememberMeValue) {
            username.setText(usernameValue)
            password.setText(passwordValue)
            rememberMe.isChecked = true
        }
    }

    //Makes sure the username and passwords are valid (not empty)
    private fun checkInput(): Boolean {
        val usernameStr = username.text.toString()
        val passwordStr = password.text.toString()

        username.error = null
        password.error = null

        var isValid = true

        if (usernameStr.isBlank()) {
            username.error = "Username cannot be empty"
            isValid = false
        }

        if (passwordStr.isBlank()) {
            password.error = "Password cannot be empty"
            isValid = false
        }

        return isValid
    }

    //Expands the editText click box for username and password
    private fun expandClickBox(view: View) {
        val usernameContainer = view.findViewById<LinearLayout>(R.id.username_container)
        val passwordContainer = view.findViewById<LinearLayout>(R.id.password_container)
        username = view.findViewById(R.id.enter_username)
        password = view.findViewById(R.id.enter_password)

        val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        //Focus the editText box and show the keyboard
        usernameContainer.setOnClickListener {
            username.requestFocus()
            imm.showSoftInput(username, InputMethodManager.SHOW_IMPLICIT)
        }

        passwordContainer.setOnClickListener {
            password.requestFocus()
            imm.showSoftInput(password, InputMethodManager.SHOW_IMPLICIT)
        }

    }


    //Check if the login exists in database
    private fun checkLogin(callback: (Boolean) -> Unit) {
        val input = username.text.toString()
        val passwordStr = password.text.toString()

        if (input.contains("@")) {
            loginWithEmail(input, passwordStr, callback)
        }
        else {
            //Look up the email by the username
            lookupEmailByUsername(input) { email ->
                if (email == null) {
                    Toast.makeText(context, "Invalid credentials", Toast.LENGTH_SHORT).show()
                    callback(false)
                    return@lookupEmailByUsername
                }
                loginWithEmail(email, passwordStr, callback)
            }
        }
    }

    //Login with email and password
    private fun loginWithEmail(email: String, password: String, callback: (Boolean) -> Unit) {
        FirebaseAuth.getInstance()
            .signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                callback(true)
            }
            .addOnFailureListener {
                Toast.makeText(context, "Invalid credentials", Toast.LENGTH_SHORT).show()
                callback(false)
            }
    }

    //Look up the email by the username
    private fun lookupEmailByUsername(username: String, callback: (String?) -> Unit) {
        FirebaseFirestore.getInstance()
            .collection("users")
            .whereEqualTo("username", username)
            .limit(1)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    callback(result.documents[0].getString("email"))
                } else {
                    callback(null)
                }
            }
            .addOnFailureListener {
                callback(null)
            }
    }







    override fun onResume() {
        super.onResume()
        (activity as? MainActivity)?.hideNavigationForAuth()
    }


}
