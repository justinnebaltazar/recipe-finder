package com.group19.recipefinder.ui.recipedetails

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.RecipeRepository
import kotlinx.coroutines.launch

class RecipeDetailsViewModel(private val repository: RecipeRepository = RecipeRepository()) : ViewModel() {

    private val _recipe = MutableLiveData<Recipe>()
    val recipe: LiveData<Recipe> = _recipe

    fun loadRecipe(initialRecipe: Recipe) {
        viewModelScope.launch {
            val fullRecipe = repository.getRecipe(initialRecipe)
            _recipe.value = fullRecipe
        }
    }
}