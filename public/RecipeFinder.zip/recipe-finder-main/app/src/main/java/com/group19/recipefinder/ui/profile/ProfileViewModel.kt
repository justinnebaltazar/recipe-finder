package com.group19.recipefinder.ui.profile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.group19.recipefinder.data.ProfileDataStore
import kotlinx.coroutines.launch

class ProfileViewModel(application: Application) : AndroidViewModel(application) {
    private val dataStore = ProfileDataStore(application)

    val name = dataStore.profileName.asLiveData()
    val email = dataStore.profileEmail.asLiveData()
    val dietary = dataStore.dietaryList.asLiveData()
    val cuisines = dataStore.cuisineList.asLiveData()

    val profileImageUri = dataStore.profileImageUri.asLiveData()

    fun updateName(name: String) = viewModelScope.launch {
        dataStore.saveName(name)
    }

    fun updateEmail(email: String) = viewModelScope.launch {
        dataStore.saveEmail(email)
    }

    fun updateDietary(list: List<String>) = viewModelScope.launch {
        dataStore.saveDietaryList(list)
    }

    fun updateCuisines(list: List<String>) = viewModelScope.launch {
        dataStore.saveCuisineList(list)
    }

    fun updateProfileImage(uri: String) = viewModelScope.launch {
        dataStore.saveProfileImage(uri)
    }

    fun removeProfileImage() = viewModelScope.launch {
        dataStore.clearProfileImage()
    }
}