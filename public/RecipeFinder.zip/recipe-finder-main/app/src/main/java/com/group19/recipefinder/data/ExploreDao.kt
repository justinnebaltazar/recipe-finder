package com.group19.recipefinder.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface ExploreRecipeDao {

    @Query("SELECT * FROM explore_recipes")
    suspend fun getAll(): List<ExploreRecipeEntity>

    @Query("SELECT COUNT(*) FROM explore_recipes WHERE id = :id")
    suspend fun countById(id: String): Int

    @Query("DELETE FROM explore_recipes WHERE id = :id")
    suspend fun deleteById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(recipe: ExploreRecipeEntity)

    @Query("DELETE FROM explore_recipes")
    suspend fun clear()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<ExploreRecipeEntity>)

    @Update
    suspend fun update(entity: ExploreRecipeEntity)

    @Query("SELECT * FROM explore_recipes WHERE id = :id")
    suspend fun getById(id: String): ExploreRecipeEntity?
}