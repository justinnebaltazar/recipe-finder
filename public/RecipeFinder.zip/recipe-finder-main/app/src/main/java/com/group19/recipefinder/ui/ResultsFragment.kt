package com.group19.recipefinder.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.MultiAutoCompleteTextView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.RecipeRepository
import com.group19.recipefinder.repository.VirtualFridgeRepository
import com.group19.recipefinder.ui.fridge.VirtualFridgeViewModel
import com.group19.recipefinder.ui.recipedetails.RecipeDetailsFragment
import com.group19.recipefinder.ui.virtualfridge.VirtualFridgeViewModelFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.InputStream
import androidx.core.widget.addTextChangedListener

class ResultsFragment : Fragment() {

    private lateinit var searchInput: MultiAutoCompleteTextView
    private lateinit var fridgeViewModel: VirtualFridgeViewModel
    private lateinit var cameraButton: ImageView
    private lateinit var resultsHeader: TextView
    private lateinit var emptyMessage: TextView
    private lateinit var searchButton: ImageView
    private lateinit var resultsList: RecyclerView
    private lateinit var loadingIndicator: ProgressBar

    private val recipes = mutableListOf<Recipe>()
    private lateinit var adapter: RecipeAdapter

    private val repository = RecipeRepository()

    private var recipeCameraUri: Uri? = null

    //
    private val takeRecipePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && recipeCameraUri != null) {
                generateRecipeFromImage(recipeCameraUri!!)
            }
        }

    private val pickRecipeImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                generateRecipeFromImage(uri)
            }
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchRecipeCamera()
            else {
                Toast.makeText(requireContext(), "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.results_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        searchInput = view.findViewById(R.id.search_input)
        cameraButton = view.findViewById(R.id.camera_button)
        resultsHeader = view.findViewById(R.id.results_header)
        emptyMessage = view.findViewById(R.id.empty_message)
        searchButton = view.findViewById(R.id.search_button)
        resultsList = view.findViewById(R.id.results_list)
        loadingIndicator = view.findViewById(R.id.loading_indicator)

        searchInput.setTokenizer(MultiAutoCompleteTextView.CommaTokenizer())

        fridgeViewModel = ViewModelProvider(
            this,
            VirtualFridgeViewModelFactory(VirtualFridgeRepository(requireContext()))
        )[VirtualFridgeViewModel::class.java]

        resultsList.layoutManager = LinearLayoutManager(requireContext())
        adapter = RecipeAdapter(recipes) { recipe ->
            val fragment = RecipeDetailsFragment.newInstance(recipe)
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
        resultsList.adapter = adapter

        searchInput.addTextChangedListener {
            val fullText = it.toString()

            // get only the last token after the last comma
            val lastToken = fullText.substringAfterLast(",").trim()

            if (lastToken.isBlank()) return@addTextChangedListener

            fridgeViewModel.searchFridge(lastToken) { items ->
                val suggestions = items.map { it.name }

                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_dropdown_item_1line,
                    suggestions
                )

                requireActivity().runOnUiThread {
                    searchInput.setAdapter(adapter)
                    searchInput.showDropDown()
                }
            }
        }


        // when user submits text via keyboard
        searchInput.setOnEditorActionListener { _, _, _ ->
            performSearch()
            true
        }

        searchButton.setOnClickListener {
            performSearch()
        }

        // camera icon click - show options for camera or gallery
        cameraButton.setOnClickListener {
            DialogManager.showRecipeImagePicker(
                context = requireContext(),
                onCameraSelected = { requestRecipeCameraPermission() },
                onGallerySelected = { launchRecipeGalleryPicker() }
            )
        }
    }

    private fun requestRecipeCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            launchRecipeCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchRecipeGalleryPicker() {
        pickRecipeImage.launch("image/*")
    }

    private fun launchRecipeCamera() {
        val file = File.createTempFile("recipe_", ".jpg", requireContext().cacheDir)

        recipeCameraUri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.provider",
            file
        )
        takeRecipePicture.launch(recipeCameraUri)
    }

    private fun generateRecipeFromImage(uri: Uri) {
        viewLifecycleOwner.lifecycleScope.launch {
            loadingIndicator.visibility = View.VISIBLE
            resultsList.visibility = View.GONE
            resultsHeader.text = getString(R.string.results_header)
            emptyMessage.visibility = View.VISIBLE
            emptyMessage.text = "Analyzing image..."

            try {
                val contentResolver = requireContext().contentResolver

                val imageBytes = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use(InputStream::readBytes)
                        ?: throw IOException("Unable to read image data")
                }

                val mimeType = contentResolver.getType(uri) ?: "image/jpeg"

                val newRecipes = withContext(Dispatchers.IO) {
                    repository.searchRecipesByImage(imageBytes, mimeType)
                }

                recipes.clear()
                recipes.addAll(newRecipes)
                adapter.notifyDataSetChanged()

                val count = newRecipes.size
                resultsHeader.text = getString(R.string.results_found_count, count)

                if (count == 0) {
                    emptyMessage.visibility = View.VISIBLE
                    emptyMessage.text = "No recipes found for this image"
                } else {
                    emptyMessage.visibility = View.GONE
                    resultsList.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error fetching recipes from image: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                resultsHeader.text = getString(R.string.results_header)
                emptyMessage.visibility = View.VISIBLE
                emptyMessage.text = getString(R.string.results_error)
                resultsList.visibility = View.GONE
            } finally {
                loadingIndicator.visibility = View.GONE
            }
        }
    }

    private fun performSearch() {
        val query = searchInput.text.toString().trim()

        if (query.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter ingredients", Toast.LENGTH_SHORT).show()
            return
        }

        // hide the keyboard after search
        val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)

        // update UI to reflect search state
        resultsHeader.text = getString(R.string.results_found_count, 0)
        emptyMessage.visibility = View.VISIBLE
        emptyMessage.text = getString(R.string.results_search)

        viewLifecycleOwner.lifecycleScope.launch {
            loadingIndicator.visibility = View.VISIBLE
            resultsList.visibility = View.GONE

            try {
                resultsHeader.text = getString(R.string.results_header)
                emptyMessage.text = getString(R.string.results_search)

                val newRecipes = withContext(Dispatchers.IO) {
                    repository.searchRecipes(query)
                }

                recipes.clear()
                recipes.addAll(newRecipes)
                adapter.notifyDataSetChanged()

                val count = newRecipes.size
                resultsHeader.text = getString(R.string.results_found_count, count)

                if (count == 0) {
                    emptyMessage.visibility = View.VISIBLE
                    emptyMessage.text = getString(R.string.results_no_recipes, query)
                } else {
                    emptyMessage.visibility = View.GONE
                    resultsList.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error fetching recipes: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                resultsHeader.text = getString(R.string.results_header)
                emptyMessage.visibility = View.VISIBLE
                emptyMessage.text = getString(R.string.results_error)
                resultsList.visibility = View.GONE
            } finally {
                loadingIndicator.visibility = View.GONE
            }
        }
    }
}