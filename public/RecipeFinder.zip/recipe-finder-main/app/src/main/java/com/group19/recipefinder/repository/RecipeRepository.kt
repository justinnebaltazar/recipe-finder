package com.group19.recipefinder.repository

import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.Part
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

class RecipeRepository {

    // for now: returns the Recipe object passed from UI
    // details screen uses this directly
    fun getRecipe(recipe: Recipe): Recipe {
        return recipe
    }

    suspend fun searchRecipes(ingredients: String): List<Recipe> {
        val apiRecipes = api.generateRecipe(RecipeRequestBody(ingredients))
        return apiRecipes.map { it.toDomain() }
    }

    suspend fun searchRecipesByImage(imageBytes: ByteArray, mimeType: String): List<Recipe> {
        val requestBody = imageBytes.toRequestBody(mimeType.toMediaTypeOrNull())
        val part = MultipartBody.Part.createFormData(
            name = "file",
            filename = "image.jpg",
            body = requestBody
        )

        val apiRecipes = api.generateRecipeFromImage(part)
        return apiRecipes.map { it.toDomain() }
    }

    // --- Networking layer ---

    private data class RecipeRequestBody(
        val ingredients: String
    )

    private data class ApiIngredient(
        val name: String,
        val amount: String
    )

    private data class ApiRecipe(
        val title: String,
        val servings: String,
        val time: String,
        val ingredientsPreview: String,
        val ingredients: List<ApiIngredient>,
        val instructions: List<String>
    ) {
        fun toDomain(): Recipe =
            Recipe(
                title = title,
                servings = servings,
                time = time,
                ingredientsPreview = ingredientsPreview,
                imageResId = R.drawable.placeholder_food,
                ingredients = ingredients.map { it.name to it.amount },
                instructions = instructions
            )
    }

    private interface RecipeApi {
        @POST("recipes")
        suspend fun generateRecipe(@Body body: RecipeRequestBody): List<ApiRecipe>

        @Multipart
        @POST("recipes/image")
        suspend fun generateRecipeFromImage(
            @Part file: MultipartBody.Part
        ): List<ApiRecipe>
    }

    companion object {
        // NOTE: When running the backend locally with the Android emulator,
        // use 10.0.2.2 to reach your machine's localhost.
        //private const val BASE_URL = "http://10.0.2.2:8000/"

        //Cloud run URL:
        private const val BASE_URL = "https://recipe-finder-backend-501051136754.us-west1.run.app/"


        private val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        private val httpClient: OkHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        private val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        private val api: RecipeApi = retrofit.create(RecipeApi::class.java)
    }
}
