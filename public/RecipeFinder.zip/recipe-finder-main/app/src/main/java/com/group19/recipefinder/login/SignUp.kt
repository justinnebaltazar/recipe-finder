package com.group19.recipefinder.login

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import com.group19.recipefinder.R
import android.widget.TextView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestore

import com.group19.recipefinder.MainActivity



class SignUp : Fragment() {

    private lateinit var email: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var confirmPassword: EditText


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_sign_up, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val loginButton = view.findViewById<TextView>(R.id.login_now_button)
        loginButton.setOnClickListener {

            //Go back to login page by popping the stack
            parentFragmentManager.popBackStack()


        }

        val createAccountButton = view.findViewById<Button>(R.id.create_account_button)
        createAccountButton.setOnClickListener {
            if (checkInput()) {
                createUser { success ->
                    if (success) {
                        parentFragmentManager.popBackStack()
                    }
                }
            }
        }

        expandClickBox(view)
    }

    //Makes sure the username and passwords are valid (not empty)
    private fun checkInput(): Boolean {
        val emailStr = email.text.toString()
        val usernameStr = username.text.toString()
        val passwordStr = password.text.toString()
        val confirmPasswordStr = confirmPassword.text.toString()

        email.error = null
        username.error = null
        password.error = null
        confirmPassword.error = null

        var isValid = true

        if (emailStr.isBlank()) {
            email.error = "Email cannot be empty"
            isValid = false
        }

        if (usernameStr.isBlank()) {
            username.error = "Username cannot be empty"
            isValid = false
        }

        if (passwordStr.isBlank()) {
            password.error = "Password cannot be empty"
            isValid = false
        }

        if (confirmPasswordStr.isBlank()) {
            confirmPassword.error = "Please confirm your password"
            isValid = false
        }

        if (passwordStr != confirmPasswordStr) {
            confirmPassword.error = "Passwords do not match"
            isValid = false
        }

        if (usernameStr.contains(" ")) {
            username.error = "Username cannot contain spaces"
            isValid = false
        }

        //Prevent user from using an email as username
        if (usernameStr.contains("@")) {
            username.error = "Username cannot contain @"
            isValid = false
        }
        
        return isValid
    }

    //Expands the editText click box for username and password
    private fun expandClickBox(view: View) {
        val emailContainer = view.findViewById<LinearLayout>(R.id.email_container)
        val usernameContainer = view.findViewById<LinearLayout>(R.id.username_container)
        val passwordContainer = view.findViewById<LinearLayout>(R.id.password_container)
        val confirmPasswordContainer = view.findViewById<LinearLayout>(R.id.confirm_password_container)
        email = view.findViewById(R.id.enter_email)
        username = view.findViewById(R.id.enter_username)
        password = view.findViewById(R.id.enter_password)
        confirmPassword = view.findViewById(R.id.enter_confirm_password)


        val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        //Focus the editText box and show the keyboard
        emailContainer.setOnClickListener {
            email.requestFocus()
            imm.showSoftInput(email, InputMethodManager.SHOW_IMPLICIT)
        }

        usernameContainer.setOnClickListener {
            username.requestFocus()
            imm.showSoftInput(username, InputMethodManager.SHOW_IMPLICIT)
        }

        passwordContainer.setOnClickListener {
            password.requestFocus()
            imm.showSoftInput(password, InputMethodManager.SHOW_IMPLICIT)
        }

        confirmPasswordContainer.setOnClickListener {
            confirmPassword.requestFocus()
            imm.showSoftInput(confirmPassword, InputMethodManager.SHOW_IMPLICIT)
        }

    }


    //Checks if the username is already in the database
    private fun checkUsernameInDatabase(username: String, callback: (Boolean) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        val usersCollection = db.collection("users")
        val query = usersCollection.whereEqualTo("username", username)

        query.get().addOnSuccessListener { result ->
            callback(!result.isEmpty)
        }.addOnFailureListener {
            callback(false)
        }

    }

    //Creates a new user in the database if info is valid
    private fun createUser(callback: (Boolean) -> Unit) {
        val emailStr = email.text.toString()
        val usernameStr = username.text.toString()
        val passwordStr = password.text.toString()

        //check for duplicate username
        checkUsernameInDatabase(usernameStr) { usernameExists ->

            if (usernameExists) {
                Toast.makeText(context, "Username already exists", Toast.LENGTH_SHORT).show()
                callback(false)
                return@checkUsernameInDatabase
            }

            val user = hashMapOf(
                "email" to emailStr,
                "username" to usernameStr
            )

            //firebase authentication will check email and password
            FirebaseAuth.getInstance()
                .createUserWithEmailAndPassword(emailStr, passwordStr)
                .addOnSuccessListener { authResult ->
                    val uid = authResult.user!!.uid

                    FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(uid)
                        .set(user)
                        .addOnSuccessListener {
                            Toast.makeText(context, "Account created!", Toast.LENGTH_SHORT).show()
                            callback(true)
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(
                                context,
                                "Failed to create account. Please try again.",
                                Toast.LENGTH_SHORT
                            ).show()
                            Log.e("SET_ERROR", "Account creation failed", e)
                            callback(false)
                        }
                }
                .addOnFailureListener { e ->
                    when (e) {
                        is FirebaseAuthUserCollisionException -> {
                            Toast.makeText(
                                context,
                                "An account with this email already exists.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        is FirebaseAuthWeakPasswordException -> {
                            Toast.makeText(
                                context,
                                "Password is too weak. Please choose a stronger one.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        is FirebaseAuthInvalidCredentialsException -> {
                            Toast.makeText(context, "Invalid email format.", Toast.LENGTH_SHORT)
                                .show()
                        }

                        else -> {
                            Toast.makeText(
                                context,
                                "Failed to create account. Please try again.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    Log.e("AUTH_ERROR", "Account creation failed", e)
                    callback(false)
                }
        }
    }



    override fun onResume() {
        super.onResume()
        (activity as? MainActivity)?.hideNavigationForAuth()

    }

}