package com.group19.recipefinder.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.ExploreRepository
import com.group19.recipefinder.ui.recipedetails.RecipeDetailsFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MySharedRecipesFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_my_shared_recipes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.shared_list)
        val emptyView = view.findViewById<TextView>(R.id.shared_empty)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val repository = ExploreRepository(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            val shared: List<Recipe> = withContext(Dispatchers.IO) {
                repository.syncUserSharedRecipes()
                repository.getUsersSharedRecipes()
            }

            if (shared.isEmpty()) {
                emptyView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                emptyView.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE

                recyclerView.adapter = RecipeAdapter(shared) { recipe ->
                    val fragment = RecipeDetailsFragment.newInstance(recipe)
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack(null)
                        .commit()
                }
            }
        }
    }
}