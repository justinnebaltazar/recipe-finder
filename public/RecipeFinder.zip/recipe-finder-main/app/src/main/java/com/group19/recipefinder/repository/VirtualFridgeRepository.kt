package com.group19.recipefinder.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.group19.recipefinder.data.FavoriteRecipeEntity
import com.group19.recipefinder.data.FridgeDatabase
import com.group19.recipefinder.data.FridgeItem
import kotlinx.coroutines.tasks.await

class VirtualFridgeRepository(context: Context) {

    private val dao = FridgeDatabase.getInstance(context).fridgeDao()
    private val firestore = FirebaseFirestore.getInstance()

    //get user id from firebase
    private fun userId(): String {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            throw IllegalStateException("User not logged in")
        }
        return user.uid
    }

    suspend fun getAllItems(): List<FridgeItem> {
        return dao.getAll()
    }

    suspend fun addItem(item: FridgeItem) {
        val generatedId = dao.insert(item).toInt()

        val itemWithId = item.copy(id = generatedId)

        //add to firestore
        val userId = userId()
        firestore.collection("users")
            .document(userId)
            .collection("fridge")
            .document(generatedId.toString())
            .set(itemWithId)
            .await()
    }

    suspend fun deleteItem(item: FridgeItem) {
        dao.delete(item)

        //delete from firestore
        val userId = userId()
        firestore.collection("users")
            .document(userId)
            .collection("fridge")
            .document(item.id.toString())
            .delete()
            .await()
    }

    //sync local favorites data with firestore data
    suspend fun syncFromFirestore() {
        val result = firestore.collection("users")
            .document(userId())
            .collection("fridge")
            .get()
            .await()

        val remoteList = result.toObjects(FridgeItem::class.java)

        val localIds = dao.getAll().map { it.id }.toSet()

        val newItems = remoteList.filter { it.id !in localIds }

        if (newItems.isNotEmpty()) {
            dao.insertAll(newItems)
        }

    }

    suspend fun searchItemsByPrefix(prefix: String): List<FridgeItem> {
        return dao.searchByPrefix(prefix)
    }

}