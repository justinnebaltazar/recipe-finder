package com.group19.recipefinder.ui.virtualfridge

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.group19.recipefinder.R
import com.group19.recipefinder.data.FridgeItem

class FridgeAdapter(
    private var items: MutableList<FridgeItem>,
    private val onDelete: (FridgeItem) -> Unit
) : RecyclerView.Adapter<FridgeAdapter.FridgeViewHolder>() {

    inner class FridgeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtName: TextView = itemView.findViewById(R.id.txt_item_name)
        val txtDate: TextView = itemView.findViewById(R.id.txt_item_date)
        val chipDiet: Chip = itemView.findViewById(R.id.chip_diet)
        val chipExpiry: Chip = itemView.findViewById(R.id.chip_expiry)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FridgeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fridge_item, parent, false)
        return FridgeViewHolder(view)
    }

    override fun onBindViewHolder(holder: FridgeViewHolder, position: Int) {
        val item = items[position]
        holder.txtName.text = item.name
        holder.txtDate.text = item.addedDate
        holder.chipDiet.text = item.itemType
        holder.chipExpiry.text = item.expiryLabel

        holder.btnDelete.setOnClickListener {
            onDelete(item)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateList(newList: List<FridgeItem>) {
        items = newList.toMutableList()
        notifyDataSetChanged()
    }
}