package com.group19.recipefinder.ui.recipedetails

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.FavoriteRepository
import com.group19.recipefinder.repository.ExploreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RecipeDetailsFragment : Fragment() {

    private lateinit var viewModel: RecipeDetailsViewModel
    private var recipe: Recipe? = null
    private var isFavorite: Boolean = false
    private var isExplore: Boolean = false


    companion object {
        private const val ARG_RECIPE = "recipe"

        fun newInstance(recipe: Recipe): RecipeDetailsFragment {
            return RecipeDetailsFragment().apply {
                arguments = bundleOf(ARG_RECIPE to recipe)
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        recipe = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arguments?.getParcelable("recipe", Recipe::class.java)
        } else {
            @Suppress("DEPRECATION")
            arguments?.getParcelable("recipe")
        })!!
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.recipe_details_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recipe = recipe ?: return

        val title = view.findViewById<TextView>(R.id.details_title)
        val servings = view.findViewById<TextView>(R.id.details_servings)
        val time = view.findViewById<TextView>(R.id.details_time)
        val image = view.findViewById<ImageView>(R.id.details_image)
        val backButton = view.findViewById<ImageView>(R.id.back_button)
        val favoriteButton = view.findViewById<ImageView>(R.id.favorite_button)
        val exploreButton = view.findViewById<ImageView>(R.id.explore_button)

        val ingredientsList = view.findViewById<LinearLayout>(R.id.ingredients_list)
        val instructionsList = view.findViewById<LinearLayout>(R.id.instructions_list)

        // base recipe info
        title.text = recipe.title
        servings.text = "${recipe.servings} servings"
        time.text = recipe.time

        // uses placeholder image for now
        recipe.imageResId?.let { image.setImageResource(it) }

        // populate both ingredients and instructions dynamically
        ingredientsList.removeAllViews()
        recipe.ingredients.forEach { (name, amount) ->
            val formattedIngredient = getString(
                R.string.ingredient_item,
                amount,
                name
            )
            val tv = TextView(requireContext()).apply {
                text = formattedIngredient
                textSize = 15f
                setTextColor(resources.getColor(R.color.black, null))
            }
            ingredientsList.addView(tv)
        }

        instructionsList.removeAllViews()
        recipe.instructions.forEachIndexed { index, step ->
            val formattedStep = getString(
                R.string.instruction_step,
                index + 1,
                step
            )
            val tv = TextView(requireContext()).apply {
                text = formattedStep
                textSize = 15f
                setTextColor(resources.getColor(R.color.black, null))
            }
            instructionsList.addView(tv)
        }

        backButton.setOnClickListener {
            requireActivity().supportFragmentManager.popBackStack()
        }

        val favoriteRepository = FavoriteRepository(requireContext())

        fun updateFavoriteUi() {
            val tintColor = if (isFavorite) {
                resources.getColor(R.color.favorite_yellow, null)
            } else {
                resources.getColor(R.color.dark_gray, null)
            }
            favoriteButton.setColorFilter(tintColor)
        }

        updateFavoriteUi()

        // initialize favorite state from DB
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val alreadyFavorite = favoriteRepository.isFavorite(recipe)
            if (alreadyFavorite) {
                isFavorite = true
                launch(Dispatchers.Main) {
                    updateFavoriteUi()
                }
            }
        }

        favoriteButton.setOnClickListener {
            if (!isFavorite) {
                // Add to favorites
                isFavorite = true
                updateFavoriteUi()

                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    favoriteRepository.addFavorite(recipe)
                }

                Toast.makeText(
                    requireContext(),
                    getString(R.string.added_to_favorites),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                // Remove from favorites
                isFavorite = false
                updateFavoriteUi()

                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    favoriteRepository.removeFavorite(recipe)
                }

                Toast.makeText(
                    requireContext(),
                    "Removed from favorites",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }





        val exploreRepository = ExploreRepository(requireContext())


        fun updateExploreUi() {
            val tintColor = if (isExplore) {
                resources.getColor(R.color.teal_700, null)
            } else {
                resources.getColor(R.color.dark_gray, null)
            }
            exploreButton.setColorFilter(tintColor)
        }

        updateExploreUi()

        // initialize explore state from DB
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val alreadyExplore = exploreRepository.isExplore(recipe)
            if (alreadyExplore) {
                isExplore = true
                launch(Dispatchers.Main) {
                    updateExploreUi()
                }
            }
        }

        exploreButton.setOnClickListener {
            if (!isExplore) {
                // Add to explores
                isExplore = true
                updateExploreUi()

                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    exploreRepository.addExplore(recipe)
                }

                Toast.makeText(
                    requireContext(),
                    "Shared",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                // Remove from explores
                isExplore = false
                updateExploreUi()

                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    exploreRepository.removeExplore(recipe)
                }

                Toast.makeText(
                    requireContext(),
                    "Removed from shared",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
