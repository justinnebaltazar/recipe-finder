package com.group19.recipefinder.data

import androidx.annotation.Keep
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
private val gson = Gson();

@Keep
@Entity(tableName = "favorite_recipes")
data class FavoriteRecipeEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val servings: String = "",
    val time: String = "",
    val ingredientsPreview: String = "",
    val imageResId: Int = 0,
    val ingredientsJson: String = "",
    val instructionsJson: String = ""
)

fun FavoriteRecipeEntity.toDomain(): Recipe {

    // ---- Ingredients (List<Pair<String, String>>) ----
    val ingredientsType = object : TypeToken<List<Pair<String, String>>>() {}.type
    val ingredients: List<Pair<String, String>> =
        gson.fromJson(ingredientsJson, ingredientsType) ?: emptyList()

    // ---- Instructions (List<String>) ----
    val instructionsType = object : TypeToken<List<String>>() {}.type
    val instructions: List<String> =
        gson.fromJson(instructionsJson, instructionsType) ?: emptyList()

    return Recipe(
        title = title,
        servings = servings,
        time = time,
        ingredientsPreview = ingredientsPreview,
        imageResId = imageResId,
        ingredients = ingredients,
        instructions = instructions
    )
}

fun Recipe.toFavoriteEntity(): FavoriteRecipeEntity {
    val ingredientsJson = gson.toJson(ingredients.toTypedArray())
    val instructionsJson = gson.toJson(instructions.toTypedArray())
    val stableId = "${title}_${servings}_${time}".hashCode().toString()

    return FavoriteRecipeEntity(
        id = stableId,
        title = title,
        servings = servings,
        time = time,
        ingredientsPreview = ingredientsPreview,
        imageResId = imageResId,
        ingredientsJson = ingredientsJson,
        instructionsJson = instructionsJson
    )
}


