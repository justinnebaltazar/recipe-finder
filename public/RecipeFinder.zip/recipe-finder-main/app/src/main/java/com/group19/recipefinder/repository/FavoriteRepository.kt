package com.group19.recipefinder.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.group19.recipefinder.data.AppDatabase
import com.group19.recipefinder.data.FavoriteRecipeEntity
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.data.toDomain
import com.group19.recipefinder.data.toFavoriteEntity
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await


class FavoriteRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).favoriteRecipeDao()
    private val firestore = FirebaseFirestore.getInstance()

    //get user id from firebase
    private fun userId(): String {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            throw IllegalStateException("User not logged in")
        }
        return user.uid
    }


    suspend fun addFavorite(recipe: Recipe) {
        val entity: FavoriteRecipeEntity = recipe.toFavoriteEntity()
        dao.insert(entity)

        //add to firestore
        val userId = userId()
        firestore.collection("users")
            .document(userId)
            .collection("favorites")
            .document(entity.id)
            .set(entity)

    }

    suspend fun getFavorites(): List<Recipe> {
        return dao.getAll().map { it.toDomain() }
    }

    suspend fun isFavorite(recipe: Recipe): Boolean {
        val id = recipe.toFavoriteEntity().id
        return dao.countById(id) > 0
    }

    suspend fun removeFavorite(recipe: Recipe) {
        val id = recipe.toFavoriteEntity().id
        dao.deleteById(id)

        //delete from firestore
        val userId = userId()
        firestore.collection("users")
            .document(userId)
            .collection("favorites")
            .document(id)
            .delete()
    }

    //sync local favorites data with firestore data
    suspend fun syncFromFirestore() {
        val result = firestore.collection("users")
            .document(userId())
            .collection("favorites")
            .get()
            .await()

        val remoteList = result.toObjects(FavoriteRecipeEntity::class.java)

        dao.clear()
        dao.insertAll(remoteList)
    }
}


