package com.group19.recipefinder

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.group19.recipefinder.data.ProfileDataStore
import com.group19.recipefinder.ui.FavoritesFragment
import com.group19.recipefinder.ui.profile.ProfileFragment
import com.group19.recipefinder.ui.ResultsFragment
import com.group19.recipefinder.ui.ExploreFragment
import com.group19.recipefinder.login.UserLogin
import com.group19.recipefinder.login.SignUp
import com.group19.recipefinder.ui.MySharedRecipesFragment
import com.group19.recipefinder.ui.virtualfridge.VirtualFridgeFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView

    private lateinit var toolbar: Toolbar
    private lateinit var toggle: ActionBarDrawerToggle

    private lateinit var resultsFragment: ResultsFragment
    private lateinit var favoritesFragment: FavoritesFragment
    private lateinit var profileFragment: ProfileFragment
    private lateinit var exploreFragment: ExploreFragment
    private lateinit var mySharedRecipesFragment: MySharedRecipesFragment

    private lateinit var userLoginFragment: UserLogin

    private lateinit var virtualFridgeFragment: VirtualFridgeFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        setContentView(R.layout.main_activity)

        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)
        toolbar = findViewById(R.id.toolbar)

        //Set up the username greeting
        val headerView = navigationView.getHeaderView(0)
        val greetingTextView = headerView.findViewById<TextView>(R.id.nav_header_greeting)
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null) {
            FirebaseFirestore.getInstance()
                .collection("users")
                .document(uid)
                .get()
                .addOnSuccessListener { result ->
                    val username = result.getString("username")
                    greetingTextView.text = "Hello, ${username ?: "User"}"
                }
        }

        //Logout button
        val logoutButton = findViewById<TextView>(R.id.nav_logout)
        logoutButton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            replaceFragment(userLoginFragment)
            drawerLayout.closeDrawer(GravityCompat.START)
        }

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.open_drawer,
            R.string.closed_drawer
        )

        drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                hideKeyboard()
            }
            override fun onDrawerOpened(drawerView: View) {}
            override fun onDrawerClosed(drawerView: View) {}
            override fun onDrawerStateChanged(newState: Int) {}
        })

        toggle.syncState()

        toggle.drawerArrowDrawable.color = ContextCompat.getColor(this, R.color.black)

        resultsFragment = ResultsFragment()
        favoritesFragment = FavoritesFragment()
        profileFragment = ProfileFragment()
        exploreFragment = ExploreFragment()
        mySharedRecipesFragment = MySharedRecipesFragment()


        userLoginFragment = UserLogin()

        supportFragmentManager.setFragmentResultListener("login_success", this) { _, _ ->
            replaceFragment(resultsFragment)
        }

        virtualFridgeFragment = VirtualFridgeFragment()

        if (savedInstanceState == null) {
            replaceFragment(userLoginFragment)
        }

        navigationView.setNavigationItemSelectedListener { menuItem ->
            when(menuItem.itemId) {
                R.id.nav_my_shared_recipes -> replaceFragment(mySharedRecipesFragment)
                R.id.nav_explore -> replaceFragment(exploreFragment)
                R.id.nav_results -> replaceFragment(resultsFragment)
                R.id.nav_favorites -> replaceFragment(favoritesFragment)
                R.id.nav_profile -> replaceFragment(profileFragment)
                R.id.nav_fridge -> replaceFragment(virtualFridgeFragment)
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        if (fragment is UserLogin || fragment is SignUp) {
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
            toolbar.visibility = View.GONE
        } else {
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
            toolbar.visibility = View.VISIBLE
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE)
                as android.view.inputmethod.InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    fun hideNavigationForAuth() {
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
        toolbar.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        // Logic to show/hide nav based on current fragment can be added here if needed
    }

    fun showNavigationForApp() {
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        toolbar.visibility = View.VISIBLE
    }
}
