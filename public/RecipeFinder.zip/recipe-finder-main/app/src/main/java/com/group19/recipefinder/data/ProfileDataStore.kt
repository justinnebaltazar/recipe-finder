package com.group19.recipefinder.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// create datastore instance
val Context.profileDataStore by preferencesDataStore(name = "profile_preferences")

class ProfileDataStore(private val context: Context) {

    companion object {
        val NAME_KEY = stringPreferencesKey("profile_name")
        val EMAIL_KEY = stringPreferencesKey("profile_email")

        val DIET_LIST_KEY = stringSetPreferencesKey("dietary_list")
        val CUISINE_LIST_KEY = stringSetPreferencesKey("cuisine_list")

        val IMAGE_URI_KEY = stringPreferencesKey("profile_image_uri")
    }

    // getters
    val profileName: Flow<String> = context.profileDataStore.data.map { prefs ->
        prefs[NAME_KEY] ?: "Your Name"
    }

    val profileEmail: Flow<String> = context.profileDataStore.data.map { prefs ->
        prefs[EMAIL_KEY] ?: "name@example.com"
    }

    val dietaryList: Flow<List<String>> = context.profileDataStore.data.map { prefs ->
        prefs[DIET_LIST_KEY]?.toList() ?: emptyList()
    }

    val cuisineList: Flow<List<String>> = context.profileDataStore.data.map { prefs ->
        prefs[CUISINE_LIST_KEY]?.toList() ?: emptyList()
    }

    val profileImageUri: Flow<String?> = context.profileDataStore.data.map { prefs ->
        prefs[IMAGE_URI_KEY]
    }

    // setter functions
    suspend fun saveName(name: String) {
        context.profileDataStore.edit { prefs ->
            prefs[NAME_KEY] = name
        }
    }

    suspend fun saveEmail(email: String) {
        context.profileDataStore.edit { prefs ->
            prefs[EMAIL_KEY] = email
        }
    }

    suspend fun saveDietaryList(list: List<String>) {
        context.profileDataStore.edit { prefs ->
            prefs[DIET_LIST_KEY] = list.toSet()
        }
    }

    suspend fun saveCuisineList(list: List<String>) {
        context.profileDataStore.edit { prefs ->
            prefs[CUISINE_LIST_KEY] = list.toSet()
        }
    }

    suspend fun saveProfileImage(uri: String) {
        context.profileDataStore.edit { prefs ->
            prefs[IMAGE_URI_KEY] = uri
        }
    }

    // let users remove profile picture
    suspend fun clearProfileImage() {
        context.profileDataStore.edit { prefs ->
            prefs.remove(IMAGE_URI_KEY)
        }
    }
}
