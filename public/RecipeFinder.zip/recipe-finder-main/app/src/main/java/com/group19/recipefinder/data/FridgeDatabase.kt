package com.group19.recipefinder.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [FridgeItem::class], version = 1, exportSchema = false)
abstract class FridgeDatabase: RoomDatabase() {
    abstract fun fridgeDao(): FridgeDao

    companion object {
        @Volatile
        private var INSTANCE: FridgeDatabase? = null

        fun getInstance(context: Context): FridgeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FridgeDatabase::class.java,
                    "fridge_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}