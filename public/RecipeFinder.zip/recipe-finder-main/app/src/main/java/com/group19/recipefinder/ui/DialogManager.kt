package com.group19.recipefinder.ui

import android.content.Context
import android.view.LayoutInflater
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.group19.recipefinder.R
import com.group19.recipefinder.ui.profile.ProfileViewModel

object DialogManager {

    // edit name
    fun showEditNameDialog(context: Context, viewModel: ProfileViewModel) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_name, null)
        val input = view.findViewById<TextInputEditText>(R.id.input_name)

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle(R.string.edit_name_title)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    viewModel.updateName(name)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }


    // edit user email
    fun showEditEmailDialog(context: Context, viewModel: ProfileViewModel) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_email, null)
        val input = view.findViewById<TextInputEditText>(R.id.input_email)

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle(R.string.edit_email_title)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val email = input.text.toString().trim()
                if (email.isNotEmpty()) {
                    viewModel.updateEmail(email)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // edit dietary restrictions
    fun showEditDietaryDialog(context: Context, viewModel: ProfileViewModel, currentList: List<String>) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_dietary, null)
        val container = view.findViewById<LinearLayout>(R.id.dietary_checkbox_container)

        val options = listOf(
            "Vegetarian", "Vegan", "Gluten-Free",
            "Dairy-Free", "Halal", "Kosher"
        )

        val checkBoxes = options.map { label ->
            CheckBox(context).apply {
                text = label
                isChecked = currentList.contains(label)
                setTextColor(ContextCompat.getColor(context, R.color.black))
            }
        }

        checkBoxes.forEach { container.addView(it) }

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle(R.string.dietary_dialog_title)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val selected = checkBoxes.filter { it.isChecked }.map { it.text.toString() }
                viewModel.updateDietary(selected)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // edit cuisine preferences
    fun showEditCuisineDialog(context: Context, viewModel: ProfileViewModel, currentList: List<String>) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_cuisine, null)
        val container = view.findViewById<LinearLayout>(R.id.cuisine_checkbox_container)

        val options = listOf(
            "Italian", "Japanese", "Korean", "Chinese",
            "Thai", "Indian", "Mexican", "French"
        )

        val checkBoxes = options.map { label ->
            CheckBox(context).apply {
                text = label
                isChecked = currentList.contains(label)
                setTextColor(ContextCompat.getColor(context, R.color.black))
            }
        }

        checkBoxes.forEach { container.addView(it) }

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle(R.string.cuisine_dialog_title)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val selected = checkBoxes.filter { it.isChecked }.map { it.text.toString() }
                viewModel.updateCuisines(selected)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // main edit menu
    fun showEditMenu(context: Context, fragment: Fragment, viewModel: ProfileViewModel) {

        val options = arrayOf(
            context.getString(R.string.edit_name),
            context.getString(R.string.edit_email),
            context.getString(R.string.edit_dietary),
            context.getString(R.string.edit_cuisines)
        )

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle(R.string.edit_profile_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showEditNameDialog(context, viewModel)
                    1 -> showEditEmailDialog(context, viewModel)
                    2 -> showEditDietaryDialog(
                        context,
                        viewModel,
                        viewModel.dietary.value ?: emptyList()
                    )
                    3 -> showEditCuisineDialog(
                        context,
                        viewModel,
                        viewModel.cuisines.value ?: emptyList()
                    )
                }
            }
            .show()
    }

    fun showAddFridgeItemDialog(
        context: Context,
        onAdd: (String, String, Int) -> Unit
    ) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_add_item, null)

        val inputName = view.findViewById<TextInputEditText>(R.id.input_item_name)
        val spinner = view.findViewById<Spinner>(R.id.spinner_category)
        val inputDays = view.findViewById<TextInputEditText>(R.id.input_days)
        val btnClose = view.findViewById<ImageView>(R.id.btn_close)

        // drop down categories for food type
        val categories = listOf("Vegetables", "Fruits", "Meat", "Dairy", "Bakery", "Poultry", "Other")
        spinner.adapter = android.widget.ArrayAdapter(
            context,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )

        val dialog = AlertDialog.Builder(context)
            .setView(view)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnClose.setOnClickListener { dialog.dismiss() }

        view.findViewById<Button>(R.id.btn_cancel).setOnClickListener {
            dialog.dismiss()
        }

        view.findViewById<Button>(R.id.btn_add).setOnClickListener {
            val name = inputName.text.toString().trim()
            val days = inputDays.text.toString().toIntOrNull() ?: 0
            val category = spinner.selectedItem.toString()

            if (name.isNotEmpty() && days > 0) {
                onAdd(name, category, days)
                dialog.dismiss()
            } else {
                inputName.error = "Required"
            }
        }

        dialog.show()
    }

    fun showProfileImagePicker(
        context: Context,
        hasExistingPhoto: Boolean,
        onCameraSelected: () -> Unit,
        onGallerySelected: () -> Unit,
        onRemoveSelected: () -> Unit
    ) {
        val options = if (hasExistingPhoto) {
            arrayOf("Take Photo", "Choose from Gallery", "Remove Photo")
        } else {
            arrayOf("Take Photo", "Choose from Gallery")
        }

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle("Profile Photo")
            .setItems(options) { _, index ->
                when (options[index]) {
                    "Take Photo" -> onCameraSelected()
                    "Choose from Gallery" -> onGallerySelected()
                    "Remove Photo" -> onRemoveSelected()
                }
            }
            .show()
    }

    fun showRecipeImagePicker(
        context: Context,
        onCameraSelected: () -> Unit,
        onGallerySelected: () -> Unit
    ) {
        val options = arrayOf("Camera", "Choose from Gallery")

        MaterialAlertDialogBuilder(
            context,
            R.style.RecipeFinder_Dialog
        )
            .setTitle("Search by Image")
            .setItems(options) { _, index ->
                when (options[index]) {
                    "Camera" -> onCameraSelected()
                    "Choose from Gallery" -> onGallerySelected()
                }
            }
            .show()
    }

}