package com.group19.recipefinder.ui.virtualfridge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.group19.recipefinder.repository.VirtualFridgeRepository
import com.group19.recipefinder.ui.fridge.VirtualFridgeViewModel

class VirtualFridgeViewModelFactory(
    private val repository: VirtualFridgeRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VirtualFridgeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VirtualFridgeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
