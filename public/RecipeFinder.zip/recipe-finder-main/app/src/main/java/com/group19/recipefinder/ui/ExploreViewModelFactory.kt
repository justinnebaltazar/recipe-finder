package com.group19.recipefinder.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.group19.recipefinder.repository.ExploreRepository

class ExploreViewModelFactory(
    private val repository: ExploreRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ExploreViewModel(repository) as T
    }
}
