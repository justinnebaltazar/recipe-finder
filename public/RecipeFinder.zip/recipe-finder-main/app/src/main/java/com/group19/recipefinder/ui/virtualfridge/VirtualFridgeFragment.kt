package com.group19.recipefinder.ui.virtualfridge

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.group19.recipefinder.R
import com.group19.recipefinder.data.FridgeItem
import com.group19.recipefinder.repository.VirtualFridgeRepository
import com.group19.recipefinder.ui.DialogManager
import com.group19.recipefinder.ui.fridge.VirtualFridgeViewModel
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class VirtualFridgeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FridgeAdapter
    private lateinit var addButton: MaterialButton

    private lateinit var chipItemsTracked: Chip
    private lateinit var chipExpiring: Chip

    // current fridge items list
    private val fridgeItems = mutableListOf<FridgeItem>()

    private lateinit var viewModel: VirtualFridgeViewModel


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.virtual_fridge_fragmet, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recycler_items)
        addButton = view.findViewById(R.id.btn_add_item)
        chipItemsTracked = view.findViewById(R.id.chip_items_tracked)
        chipExpiring = view.findViewById(R.id.chip_expiring)

        val repository = VirtualFridgeRepository(requireContext())
        val factory = VirtualFridgeViewModelFactory(repository)

        viewModel = ViewModelProvider(this, factory)[VirtualFridgeViewModel::class.java]

        adapter = FridgeAdapter(fridgeItems) { item ->
            viewModel.deleteItem(item)
        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.items.collect { items ->
                    fridgeItems.clear()
                    fridgeItems.addAll(items)
                    adapter.updateList(fridgeItems)
                    updateSummaryChips()
                }
            }
        }

        addButton.setOnClickListener {
            DialogManager.showAddFridgeItemDialog(requireContext()) { name, category, days ->

                val newItem = FridgeItem(
                    name = name,
                    addedDate = "Added ${getTodayDate()}",
                    itemType = category,
                    daysUntilExpiry = days
                )

                viewModel.addItem(newItem)
            }
        }

        // init chips
        updateSummaryChips()
    }

    // updates top chips dynamically
    private fun updateSummaryChips() {
        val total = fridgeItems.size
        val expiringSoon = fridgeItems.count { it.daysUntilExpiry < 5 }

        chipItemsTracked.text = "$total items tracked"
        chipExpiring.text = "$expiringSoon items expiring soon!"
    }

    private fun getTodayDate(): String {
        val formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy")
        return LocalDate.now().format(formatter)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshFromLocal()
    }

}
