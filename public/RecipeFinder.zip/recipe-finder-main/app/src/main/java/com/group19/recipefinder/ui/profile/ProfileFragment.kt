package com.group19.recipefinder.ui.profile

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.group19.recipefinder.R
import com.group19.recipefinder.ui.DialogManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import java.io.File

class ProfileFragment : Fragment() {

    private lateinit var profileAvatar: ImageView
    private lateinit var profileName: TextView
    private lateinit var profileEmail: TextView

    private lateinit var dietaryGroup: ChipGroup
    private lateinit var dietaryEmptyTextView: TextView

    private lateinit var cuisineGroup: ChipGroup
    private lateinit var cuisineEmptyTextView: TextView

    private lateinit var editProfileButton: Button

    private val viewModel: ProfileViewModel by viewModels()

    private var cameraImageUri: Uri? = null

    private var hasProfilePhoto = false

    private val pickGalleryImage =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            uri?.let {
                profileAvatar.setImageURI(it)
                saveProfileImage(it)
            }
        }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success && cameraImageUri != null) {
                profileAvatar.setImageURI(cameraImageUri)
                saveProfileImage(cameraImageUri!!)
            }
        }

    private val avatarPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchAvatarCamera()
            else {
                Toast.makeText(requireContext(), "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.profile_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // bind UI elements
        profileAvatar = view.findViewById(R.id.profile_avatar)
        profileName = view.findViewById(R.id.profile_name)
        profileEmail = view.findViewById(R.id.profile_email)

        dietaryGroup = view.findViewById(R.id.dietary_group)
        dietaryEmptyTextView = view.findViewById(R.id.dietary_empty_text)

        cuisineGroup = view.findViewById(R.id.cuisine_group)
        cuisineEmptyTextView = view.findViewById(R.id.cuisine_empty_text)

        editProfileButton = view.findViewById(R.id.edit_profile_button)

        viewModel.name.observe(viewLifecycleOwner) {
            profileName.text = it
        }

        viewModel.email.observe(viewLifecycleOwner) {
            profileEmail.text = it
        }

        viewModel.dietary.observe(viewLifecycleOwner) { updateDietaryChips(it) }
        viewModel.cuisines.observe(viewLifecycleOwner) { updateCuisineChips(it) }

        // observe image + track if user has profile
        viewModel.profileImageUri.observe(viewLifecycleOwner) { uriString ->
            if (uriString != null) {
                hasProfilePhoto = true
                profileAvatar.setImageURI(uriString.toUri())
            } else {
                hasProfilePhoto = false
                profileAvatar.setImageResource(R.drawable.ic_profile) // default avatar
            }
        }


        editProfileButton.setOnClickListener {
            DialogManager.showEditMenu(
                requireContext(),
                this,
                viewModel
            )
        }

        // tap profile picture to open camera or gallery
        profileAvatar.setOnClickListener {
            DialogManager.showProfileImagePicker(
                context = requireContext(),
                hasExistingPhoto = hasProfilePhoto,
                onCameraSelected = { requestAvatarCameraPermission() },
                onGallerySelected = { openGallery() },
                onRemoveSelected = { removeProfilePhoto() }
            )
        }
    }

    private fun openGallery() {
        pickGalleryImage.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    private fun requestAvatarCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            launchAvatarCamera()
        } else {
            avatarPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchAvatarCamera() {
        val file = File.createTempFile("avatar_", ".jpg", requireContext().cacheDir)

        cameraImageUri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.provider",
            file
        )

        takePicture.launch(cameraImageUri)
    }

    private fun updateDietaryChips(list: List<String>) {
        dietaryGroup.removeAllViews()

        if (list.isEmpty()) {
            dietaryEmptyTextView.visibility = View.VISIBLE
            return
        }

        dietaryEmptyTextView.visibility = View.GONE

        list.forEach { label ->
            val chip = layoutInflater.inflate(
                R.layout.chip_diet,
                dietaryGroup,
                false
            ) as Chip
            chip.text = label
            dietaryGroup.addView(chip)

        }
    }

    private fun updateCuisineChips(list: List<String>) {
        cuisineGroup.removeAllViews()

        if (list.isEmpty()) {
            cuisineEmptyTextView.visibility = View.VISIBLE
            return
        }

        cuisineEmptyTextView.visibility = View.GONE

        list.forEach { label ->
            val chip = layoutInflater.inflate(
                R.layout.chip_cuisine,
                cuisineGroup,
                false
            ) as Chip
            chip.text = label
            cuisineGroup.addView(chip)
        }
    }

    private fun saveProfileImage(uri: Uri) {
        viewModel.updateProfileImage(uri.toString())
    }

    private fun removeProfilePhoto() {
        profileAvatar.setImageResource(R.drawable.ic_profile)
        viewModel.removeProfileImage()
        Toast.makeText(requireContext(), "Profile photo removed", Toast.LENGTH_SHORT).show()
    }

}