package com.group19.recipefinder.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.ExploreRepository
import kotlinx.coroutines.launch

class ExploreViewModel(
    private val repository: ExploreRepository
) : ViewModel() {

    private val _recipe = MutableLiveData<Recipe>()
    val recipe: LiveData<Recipe> = _recipe

    private var shuffledList: List<Recipe> = emptyList()
    private var currentIndex = 0

    //Get the recipes from database and mix the list, then iterate through the list of recipes
    fun loadNextRecipe() {
        viewModelScope.launch {

            if (shuffledList.isEmpty()) {
                repository.syncAllSharedRecipes()
                shuffledList = repository.getExplores().shuffled()
                currentIndex = 0
            }

            if (shuffledList.isNotEmpty()) {
                _recipe.value = shuffledList[currentIndex]

                //Loop the list
                currentIndex = (currentIndex + 1) % shuffledList.size
            }
        }
    }
}

