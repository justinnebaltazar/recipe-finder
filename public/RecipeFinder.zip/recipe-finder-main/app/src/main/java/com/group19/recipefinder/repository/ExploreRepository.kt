package com.group19.recipefinder.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.group19.recipefinder.data.AppDatabase
import com.group19.recipefinder.data.ExploreRecipeEntity
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.data.toDomain
import com.group19.recipefinder.data.toExploreEntity
import kotlinx.coroutines.tasks.await

class ExploreRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).exploreRecipeDao()
    private val firestore = FirebaseFirestore.getInstance()

    private fun userId(): String {
        return FirebaseAuth.getInstance().currentUser?.uid
            ?: throw IllegalStateException("User not logged in")
    }

    suspend fun getUserName(): String {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: return "User" // fallback if not logged in

        return try {
            val doc = firestore.collection("users")
                .document(uid)
                .get()
                .await() // suspend until Firestore returns
            doc.getString("username") ?: "User"
        } catch (e: Exception) {
            "User"
        }
    }

    // Add explore recipe
    suspend fun addExplore(recipe: Recipe) {
        val uid = userId()
        val username = getUserName() // suspend call

        var entity = recipe.toExploreEntity().copy(
            author = username,
            authorId = uid,
            timestamp = System.currentTimeMillis()
        )

        // 2. Insert locally (REPLACE if exists)
        dao.insert(entity)

        // 3. Create Firestore doc
        val docRef = firestore.collection("SharedRecipes").document()
        val firestoreId = docRef.id

        // 4. Save Firestore ID into local Room entity
        entity = entity.copy(firestoreId = firestoreId)
        dao.update(entity)

        // 5. Upload full entity to Firestore
        docRef.set(entity).await()
    }

    suspend fun getExplores(): List<Recipe> {
        return dao.getAll().map { it.toDomain() }
    }

    suspend fun getUsersSharedRecipes(): List<Recipe> {
        val uid = userId()
        return dao.getAll().filter { it.authorId == uid }.map { it.toDomain() }
    }

    suspend fun isExplore(recipe: Recipe): Boolean {
        val id = recipe.toExploreEntity().id
        return dao.countById(id) > 0
    }

    suspend fun removeExplore(recipe: Recipe) {
        // 1. Get the entity from local DB (includes firestoreId)
        val entity = dao.getById(recipe.toExploreEntity().id) ?: return

        // 2. Delete locally
        dao.deleteById(entity.id)

        // 3. Delete from Firestore
        entity.firestoreId?.let { fsId ->
            firestore.collection("SharedRecipes")
                .document(fsId)
                .delete()
                .await()
        }
    }

    suspend fun getRandomRecipe(): Recipe {
        val list = dao.getAll().map { it.toDomain() }
        return list.random()
    }



    suspend fun syncAllSharedRecipes() {
        val snapshot = firestore.collection("SharedRecipes")
            .get()
            .await()

        val remote = snapshot.toObjects(ExploreRecipeEntity::class.java)

        dao.clear()
        dao.insertAll(remote)
    }

    suspend fun syncUserSharedRecipes() {
        val uid = userId()

        // Query only documents where authorId == the current user
        val snapshot = firestore.collection("SharedRecipes")
            .whereEqualTo("authorId", uid)
            .get()
            .await()

        val remote = snapshot.toObjects(ExploreRecipeEntity::class.java)

        dao.clear()
        dao.insertAll(remote)
    }

}
