package com.group19.recipefinder.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.group19.recipefinder.R
import com.group19.recipefinder.data.Recipe
import com.group19.recipefinder.repository.FavoriteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.group19.recipefinder.ui.recipedetails.RecipeDetailsFragment
import android.widget.TextView
class FavoritesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.favorites_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.favorites_list)
        val emptyView = view.findViewById<TextView>(R.id.favorites_empty)

        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val repository = FavoriteRepository(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            val favorites: List<Recipe> = withContext(Dispatchers.IO) {
                repository.syncFromFirestore()
                repository.getFavorites()
            }

            if (favorites.isEmpty()) {
                emptyView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {
                emptyView.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE

                recyclerView.adapter = RecipeAdapter(favorites) { recipe ->
                    val fragment = RecipeDetailsFragment.newInstance(recipe)
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack(null)
                        .commit()
                }
            }
        }
    }
}
