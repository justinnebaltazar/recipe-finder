package com.group19.recipefinder.ui.fridge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.group19.recipefinder.data.FridgeItem
import com.group19.recipefinder.repository.VirtualFridgeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class VirtualFridgeViewModel(
    private val repository: VirtualFridgeRepository
) : ViewModel() {

    private val _items = MutableStateFlow<List<FridgeItem>>(emptyList())
    val items: StateFlow<List<FridgeItem>> = _items

    init {
        refreshFromLocal()
    }

     fun refreshFromLocal() {
        viewModelScope.launch(Dispatchers.IO) {
            _items.value = repository.getAllItems()
        }
    }

    private fun syncFromRemote() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.syncFromFirestore()
            _items.value = repository.getAllItems()
        }
    }

    fun addItem(item: FridgeItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addItem(item)
            _items.value = repository.getAllItems()
        }
    }

    fun deleteItem(item: FridgeItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteItem(item)
            _items.value = repository.getAllItems()
        }
    }

    fun searchFridge(
        prefix: String,
        onResult: (List<FridgeItem>) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = repository.searchItemsByPrefix(prefix)
            onResult(result)
        }
    }
}

